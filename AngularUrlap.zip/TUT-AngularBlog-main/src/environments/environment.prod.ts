export const environment = {
  production: true,
  apiRoot: 'https://jsonplaceholder.typicode.com'
};
